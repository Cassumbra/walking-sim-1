Patchzer "Terraria" v1.8.2 - Alt Unicorn Mount - XNA version
By Zilem

__________________________________________________________________________
Installing:

Extract the .xna files from within the Zip into your Terraria's Image folder

Open your steam Library
Right click on Terraria and Select "Propperties"
go to the "Local files" tap, click on "Browse Local Files..."
Default: "Steam\steamapps\common\terraria\Content\Images"


(Windows)
open the Folder "Content" then the "Images" folder
you Finally extract the .xnb textures from the Zip to this folder


(Mac)
Right click on "Terraria" and chose "Show Package Contents"
open the Folder "Contents" then "Content" and then "Images" folder
you Finally extract the .xnb textures from the Zip to this folder

__________________________________________________________________________
Removal:

!! Either backup your Terraria folder or have Steam re-install Terraria, via file verification !!


#1 (PC) Remove the Image folder
Default: "Steam\steamapps\common\terraria\Content\Images"

#1 (MAC) Remove the Terraria file in the terraria folder
Default: "Steam\steamapps\common\terraria\*

#2 Open op your steam Library
Right click on Terraria and Select "Propperties"
go to the "Local files" tap, click on "Verify game-cache Integrity"
Steam will now check for the Missing files, and will download the original Terraria textures
__________________________________________________________________________

 -Realeased 3/November/2011
 -Updated 4/September/2015
 -Zilem - http://www.picturechaos.dk/Patchzer/PG12/Terraria.html